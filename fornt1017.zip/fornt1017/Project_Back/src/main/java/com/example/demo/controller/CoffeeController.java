package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CustomerCTranrq;
import com.example.demo.dto.CustomerCTranrs;
import com.example.demo.service.CustomerCreateSvc;

@RestController
public class CoffeeController {
    
    @Autowired
    private CustomerCreateSvc customerCreateSvc;
    
    @PostMapping("/customer/create")
    public CustomerCTranrs create(@Valid
    @RequestBody
    CustomerCTranrq customerCTranrq, Errors err)  {
        
        return customerCreateSvc.create(customerCTranrq);
    }
}
