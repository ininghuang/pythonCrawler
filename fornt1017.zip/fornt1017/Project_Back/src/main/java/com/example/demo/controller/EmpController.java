package com.example.demo.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.EmpCTranrq;
import com.example.demo.dto.EmpCTranrs;
import com.example.demo.dto.EmpDTranrq;
import com.example.demo.dto.EmpDTranrs;
import com.example.demo.dto.EmpQTranrq;
import com.example.demo.dto.EmpQTranrs;
import com.example.demo.dto.EmpUTranrq;
import com.example.demo.dto.EmpUTranrs;
import com.example.demo.exception.DataNotFoundException;
import com.example.demo.exception.ErrorInputException;
import com.example.demo.service.EmpCreateSvc;
import com.example.demo.service.EmpQuerySvc;

@RestController
@CrossOrigin("*")
public class EmpController {

	@Autowired
	private EmpQuerySvc empQuerySvc;
	
	@Autowired
	private EmpCreateSvc empCreateSvc;

	// 查詢EMP
	@PostMapping("/emp/query{id}")
	public EmpQTranrs queryItems(@RequestBody EmpQTranrq empRequest, Errors errors)
			throws DataNotFoundException, ErrorInputException, IOException {
		if (errors.hasErrors()) {
			throw new ErrorInputException();
		}
		return empQuerySvc.query(empRequest);
	}

	// 新增EMP
	@PostMapping("/emp/create")
	public EmpCTranrs create(@Valid @RequestBody EmpCTranrq tranrq, Errors errors ) throws ErrorInputException, IOException {
		if (errors.hasErrors()) {
			throw new ErrorInputException();
		}
		return empCreateSvc.create(tranrq);
	}


	//刪除EMP
	@PostMapping("/emp/delect")
	public EmpDTranrs delect(@Valid @RequestBody EmpDTranrq tranrq, Errors errors ) throws ErrorInputException, IOException, DataNotFoundException {
		if (errors.hasErrors()) {
			throw new ErrorInputException();
		}
		return empCreateSvc.delect(tranrq);
	}

	//修改EMP
	@PostMapping("/emp/update")
	public EmpUTranrs update(@Valid @RequestBody EmpUTranrq tranrq, Errors errors ) throws ErrorInputException, IOException, DataNotFoundException {
		if (errors.hasErrors()) {
			throw new ErrorInputException();
		}
		return empCreateSvc.update(tranrq);
	}
	
	
	
	

}
