package com.example.demo.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CustomerCTranrq {

    @JsonProperty("ACCOUNT")
    private String account;

    @JsonProperty("NAME")
    private String name;
   
    @JsonProperty("BIRTHDAY")
    private Date birthday;
 
    @JsonProperty("SEX")
    private String sex;
   
    @JsonProperty("ADDRESS")
    private String address;
    
    @JsonProperty("EMAIL")
    private String email;
    
    @JsonProperty("MOBILE")
    private String mobile;
    
    @JsonProperty("PASSWORD")
    private String password;
    
}
