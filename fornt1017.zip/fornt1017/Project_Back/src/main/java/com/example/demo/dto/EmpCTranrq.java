package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmpCTranrq {

	@JsonProperty("EMP_ID")
	private String empId;

	@JsonProperty("EMP_NAME")
	private String empName;

	@JsonProperty("PASSWORD")
	private String password;

	@JsonProperty("AUTHORITY")
	private String authority;
}
