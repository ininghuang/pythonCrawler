package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmpDTranrs {

    @JsonProperty("RESPONSE")
    private String response ;

}