package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmpQTranrq {

	@JsonProperty("EMP_NAME")
	private String empName;

	@JsonProperty("page")
	private EmpQTranrqPage page ;

	
}
