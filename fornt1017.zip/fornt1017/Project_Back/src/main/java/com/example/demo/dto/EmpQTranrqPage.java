package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class EmpQTranrqPage {
	
	@JsonProperty("pageNumber")
	private Number pageNumber;
	
	@JsonProperty("pageSize")
	private Number pageSize;

}
