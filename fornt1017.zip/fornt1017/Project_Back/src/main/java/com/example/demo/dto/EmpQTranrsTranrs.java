package com.example.demo.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class EmpQTranrsTranrs {

	@JsonProperty("pageSize")
	private Number pageSize;
	
	
	@JsonProperty("pageNumber")
	private Number pageNumber;
	
	
	@JsonProperty("totalPage")
	private Number totalPage;
	
	@JsonProperty("totalCount")
	private Number totalCount;
	
	@JsonProperty("items")
	private List<EmpQTranrsTranrsItems> items;
	
}
