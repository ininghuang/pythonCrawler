package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmpUTranrq {

	@JsonProperty("ID")
	private String id;

	@JsonProperty("NAME")
	private String name;

	@JsonProperty("PASSWORD")
	private String password;

	@JsonProperty("AUTHORITY")
	private String authority;
}
