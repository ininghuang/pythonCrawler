package com.example.demo.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "COFFEE_CUSTOMER")
public class CoffeeCustomerEntity implements Serializable{

    /** 序列化 */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ACCOUNT")
    private String account;

    @Column(name = "NAME")
    private String name;
   
    @Column(name = "BIRTHDAY")
    private Date birthday;
 
    @Column(name = "SEX")
    private String sex;
   
    @Column(name = "ADDRESS")
    private String address;
    
    @Column(name = "EMAIL")
    private String email;
    
    @Column(name = "MOBILE")
    private String mobile;
    
    @Column(name = "PASSWORD")
    private String password;
    
}
