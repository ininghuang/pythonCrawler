package com.example.demo.exception;

public class ErrorInputException extends Exception {
	  private static final long serialVersionUID = 1L;
}
