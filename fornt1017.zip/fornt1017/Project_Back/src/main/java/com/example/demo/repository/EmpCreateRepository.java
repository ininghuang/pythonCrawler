package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.EmpEntity;

@Repository
public interface EmpCreateRepository extends JpaRepository<EmpEntity, Long> {
	@Query(value = "select max(TO_NUMBER(STUDENT.COFFEE_EMP.EMP_ID)) from STUDENT.COFFEE_EMP", nativeQuery = true)
	String findEmpId();
}
