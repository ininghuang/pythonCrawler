package com.example.demo.service;

import com.example.demo.dto.CustomerCTranrq;
import com.example.demo.dto.CustomerCTranrs;

public interface CustomerCreateSvc {

    CustomerCTranrs create(CustomerCTranrq customerCTranrq);
}
