package com.example.demo.service;

import java.io.IOException;

import javax.validation.Valid;

import com.example.demo.dto.EmpCTranrq;
import com.example.demo.dto.EmpCTranrs;
import com.example.demo.dto.EmpDTranrq;
import com.example.demo.dto.EmpDTranrs;
import com.example.demo.dto.EmpUTranrq;
import com.example.demo.dto.EmpUTranrs;
import com.example.demo.exception.DataNotFoundException;
import com.example.demo.exception.ErrorInputException;

public interface EmpCreateSvc {

	EmpCTranrs create(EmpCTranrq tranrq) throws ErrorInputException, IOException;

	EmpDTranrs delect(@Valid EmpDTranrq tranrq)throws ErrorInputException, IOException, DataNotFoundException;

	EmpUTranrs update(@Valid EmpUTranrq tranrq)throws ErrorInputException, IOException, DataNotFoundException;

}