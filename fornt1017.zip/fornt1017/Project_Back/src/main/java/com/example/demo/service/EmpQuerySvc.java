package com.example.demo.service;

import java.io.IOException;

import com.example.demo.dto.EmpQTranrq;
import com.example.demo.dto.EmpQTranrs;
import com.example.demo.exception.DataNotFoundException;

public interface EmpQuerySvc {

	
	EmpQTranrs query(EmpQTranrq empRequest) throws DataNotFoundException, IOException;
}
