package com.example.demo.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.CustomerCTranrq;
import com.example.demo.dto.CustomerCTranrs;
import com.example.demo.entity.CoffeeCustomerEntity;
import com.example.demo.repository.CoffeeCustomerRepository;
import com.example.demo.service.CustomerCreateSvc;

@Service
public class CustomerCreateSvcImpl implements CustomerCreateSvc{

    @Autowired
    private CoffeeCustomerRepository coffeeCustomerRepository;
    
    @Transactional
    @Override
    public CustomerCTranrs create(CustomerCTranrq customerCTranrq) {
        CoffeeCustomerEntity entity = new CoffeeCustomerEntity();
        entity.setAccount(customerCTranrq.getAccount());
        entity.setAddress(customerCTranrq.getAddress());
        entity.setBirthday(customerCTranrq.getBirthday());
        entity.setEmail(customerCTranrq.getEmail());
        entity.setMobile(customerCTranrq.getMobile());
        entity.setName(customerCTranrq.getName());
        entity.setPassword(customerCTranrq.getPassword());
        entity.setSex(customerCTranrq.getSex());
        coffeeCustomerRepository.save(entity);
        CustomerCTranrs customerCTranrs = new CustomerCTranrs();
        customerCTranrs.setResponse("新增成功");
        return customerCTranrs;
    }

}
