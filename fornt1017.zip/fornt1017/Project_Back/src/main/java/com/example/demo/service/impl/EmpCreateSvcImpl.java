package com.example.demo.service.impl;

import java.io.IOException;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.dto.EmpCTranrq;
import com.example.demo.dto.EmpCTranrs;
import com.example.demo.dto.EmpDTranrq;
import com.example.demo.dto.EmpDTranrs;
import com.example.demo.dto.EmpUTranrq;
import com.example.demo.dto.EmpUTranrs;
import com.example.demo.entity.EmpEntity;
import com.example.demo.exception.DataNotFoundException;
import com.example.demo.exception.ErrorInputException;
import com.example.demo.repository.EmpCreateRepository;
import com.example.demo.repository.EmpRepository;
import com.example.demo.service.EmpCreateSvc;

@Service
public class EmpCreateSvcImpl implements EmpCreateSvc {

	@Autowired
	private EmpRepository empRepository;

	@Autowired
	private EmpCreateRepository empCreateRepository;

	// 新增
	@Override
	public EmpCTranrs create(EmpCTranrq tranrq) throws IOException {
		Integer newEmpId;
		if (empCreateRepository.findEmpId() == null) {
			newEmpId = 1;
		} else {
			newEmpId = Integer.parseInt(empCreateRepository.findEmpId()) + 1;
		}
		EmpEntity entity = new EmpEntity();
		entity.setEmpId(newEmpId.toString());
		entity.setEmpName(tranrq.getEmpName());
		entity.setPassword(tranrq.getPassword());
		entity.setAuthority(tranrq.getAuthority());
		empCreateRepository.save(entity);

		EmpCTranrs tranrs = new EmpCTranrs();
		tranrs.setResponse("交易成功");

		return tranrs;
	}

	// 刪除
	@Override
	public EmpDTranrs delect(@Valid EmpDTranrq tranrq) throws DataNotFoundException, IOException {
		String empId = tranrq.getEmpId();
		Optional<EmpEntity> entityOptional = empRepository.findById(empId);
		if (!entityOptional.isPresent()) {
			throw new DataNotFoundException();
		}
		empRepository.delete(entityOptional.get());
		EmpDTranrs tranrs = new EmpDTranrs();
		tranrs.setResponse("交易成功");

		return tranrs;
	}

	// 修改
	@Override
	public EmpUTranrs update(@Valid EmpUTranrq tranrq) throws ErrorInputException, IOException, DataNotFoundException {
		String empId = tranrq.getId();
		Optional<EmpEntity> entityOptional = empRepository.findById(empId);
		
		if (!entityOptional.isPresent()) {
			throw new DataNotFoundException();
		}
		EmpEntity entity = entityOptional.get();
		entity.setEmpId(tranrq.getId());
		entity.setEmpName(tranrq.getName());
		entity.setAuthority(tranrq.getAuthority());
		entity.setPassword(tranrq.getPassword());
		empRepository.save(entity);

		EmpUTranrs tranrs = new EmpUTranrs();
		tranrs.setResponse("交易成功");
		return tranrs;
	}

}
