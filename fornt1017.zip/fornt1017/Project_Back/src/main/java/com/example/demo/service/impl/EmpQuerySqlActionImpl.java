package com.example.demo.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.dto.EmpQTranrq;
import com.example.demo.dto.EmpQTranrs;
import com.example.demo.dto.EmpQTranrsTranrs;
import com.example.demo.dto.EmpQTranrsTranrsItems;
import com.example.demo.exception.DataNotFoundException;
import com.example.demo.service.EmpQuerySvc;
import com.example.demo.sql.SqlAction;
import com.example.demo.sql.SqlUtils;

@Service
@Transactional

public class EmpQuerySqlActionImpl implements EmpQuerySvc {

	@Autowired
	private SqlAction sqlAction;

	@Autowired
	private SqlUtils sqlUtils;

	
	@Override
	// 模糊查詢員工姓名 及 全查
	public EmpQTranrs query(EmpQTranrq empRequest) throws DataNotFoundException, IOException {
		String empName = empRequest.getEmpName();
		int getPageNumber = (int) empRequest.getPage().getPageNumber();
		int getPageSize = (int) empRequest.getPage().getPageSize();
		int pageSizeIndex = getPageNumber * getPageSize;

		Map<String, Object> totalCountMap = new HashMap<>();
		// 模糊查詢 "%"
		totalCountMap.put("EMP_NAME", ("%" + empName + "%"));
		// 分業處理
		String totalCountSql = sqlUtils.getDynamicQuerySQL("EmpQTranrs_QUERY_TOTALCOUNT.sql", totalCountMap);
		List<Map<String, Object>> totalCountEntity = sqlAction.queryForList(totalCountSql, totalCountMap);
		double totalCount = ((BigDecimal) totalCountEntity.get(0).get("TOTALCOUNT")).intValue();
		int totalPage = (int) Math.ceil(totalCount / pageSizeIndex);

		Map<String, Object> parmMap = new HashMap<>();
		parmMap.put("EMP_NAME", ("%" + empName + "%"));
		parmMap.put("pageSizeIndex", pageSizeIndex);
		parmMap.put("pageSize", getPageSize);

		String sql = sqlUtils.getDynamicQuerySQL("EmpQTranrs_QUERY_.sql", parmMap);
		List<EmpQTranrsTranrsItems> listItems = new ArrayList<>();

		List<Map<String, Object>> getData = sqlAction.queryForList(sql, parmMap);
		if (getData.isEmpty()) {
			throw new DataNotFoundException();
		}
		for (Map<String, Object> data : getData) {
			EmpQTranrsTranrsItems items = new EmpQTranrsTranrsItems();
			items.setEmpId((String) data.get("EMP_ID"));
			items.setEmpName((String) data.get("EMP_NAME"));
			items.setPassword((String) data.get("PASSWORD"));
			items.setAuthority((String) data.get("AUTHORITY"));
			listItems.add(items);
		}

		EmpQTranrs tranrs = new EmpQTranrs();
		tranrs.setResponse("交易成功");
		EmpQTranrsTranrs tranrsTranrs = new EmpQTranrsTranrs();
		tranrsTranrs.setPageNumber(getPageNumber);
		tranrsTranrs.setPageSize(getPageSize);
		tranrsTranrs.setTotalCount(totalCount);
		tranrsTranrs.setTotalPage(totalPage);
		tranrsTranrs.setItems(listItems);
		tranrs.setTranrs(tranrsTranrs);

		return tranrs;
	}




}
