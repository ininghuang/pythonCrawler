insert into STUDENT.COFFEE_EMP (EMP_ID, EMP_NAME , PASSWORD , AUTHORITY )
values( :empId, :empName , :password , :authority)
