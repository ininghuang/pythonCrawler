select max(cast(EMP_ID as int))
 from STUDENT.COFFEE_EMP