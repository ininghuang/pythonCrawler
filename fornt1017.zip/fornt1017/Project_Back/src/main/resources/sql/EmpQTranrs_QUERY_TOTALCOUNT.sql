select count(EMP.EMP_ID) as TOTALCOUNT
 from STUDENT.COFFEE_EMP EMP
 where EMP_NAME like :EMP_NAME
