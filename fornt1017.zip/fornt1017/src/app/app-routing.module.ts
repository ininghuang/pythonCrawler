import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './components/admin/admin.component';
import { MainComponent } from './components/main/main.component';
import { MemberComponent } from './components/member/member.component';
import { ProductComponent } from './components/product/product.component';
import { Product1Component } from './components/product1/product1.component';
import { Product2Component } from './components/product2/product2.component';
import { Product3Component } from './components/product3/product3.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { AdminOrderComponent } from './components/admin-order/admin-order.component';
import { AdminProductComponent } from './components/admin-product/admin-product.component';
import { MemberInfoComponent } from './components/member-info/member-info.component';
import {} from '@angular/material/table';



const routes: Routes = [
  {
    path: 'admin',
    component: AdminComponent
  },
  {
    path: 'adminMember',
    component: MemberComponent
  },
  {
    path: 'adminOrder',
    component: AdminOrderComponent
  },
  {
    path: 'adminProduct',
    component: AdminProductComponent
  },
  {
    path: '',
    component: MainComponent
  },
  {
    path: 'member',
    component: MemberComponent
  },
  {
    path: 'memberInfo',
    component: MemberInfoComponent
  },
  {
    path: 'product',
    component: ProductComponent
  },
  {
    path: 'product1',
    component: Product1Component
  },
  {
    path: 'product2',
    component: Product2Component
  },
  {
    path: 'product3',
    component: Product3Component
  },
  {
    path: 'cart',
    component: ShoppingCartComponent
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
