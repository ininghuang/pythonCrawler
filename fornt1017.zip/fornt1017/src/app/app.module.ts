import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminOrderComponent } from './components/admin-order/admin-order.component';
import { AdminProductComponent } from './components/admin-product/admin-product.component';
import { AdminComponent } from './components/admin/admin.component';
import { MainComponent } from './components/main/main.component';
import { MemberInfoComponent } from './components/member-info/member-info.component';
import { MemberComponent } from './components/member/member.component';
import { ProductComponent } from './components/product/product.component';
import { Product1Component } from './components/product1/product1.component';
import { Product2Component } from './components/product2/product2.component';
import { Product3Component } from './components/product3/product3.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { TestDialogComponent } from './shared/test-dialog/test-dialog.component';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { AdminEmpComponent } from './components/admin-emp/admin-emp.component';
import { AdminMumberComponent } from './components/admin-mumber/admin-mumber.component';
import { AdminTopComponent } from './components/admin-top/admin-top.component';
import { PsychologicalanswerComponent } from './components/psychologicalanswer/psychologicalanswer.component';
import { PsychologicaltestComponent } from './components/psychologicaltest/psychologicaltest.component';
import { TopbarAfterComponent } from './components/topbar-after/topbar-after.component';
import { TopbarComponent } from './components/topbar/topbar.component';
import { AdminEmpListComponent } from './components/admin-emp-list/admin-emp-list.component';


@NgModule({
  declarations: [
    AppComponent,
    TestDialogComponent,
    AdminComponent,
    MainComponent,
    MemberComponent,
    ProductComponent,
    Product1Component,
    Product2Component,
    Product3Component,
    ShoppingCartComponent,
    AdminOrderComponent,
    AdminProductComponent,
    MemberInfoComponent,
    PsychologicaltestComponent,
    PsychologicalanswerComponent,
    TopbarComponent,
    TopbarAfterComponent,
    AdminTopComponent,
    AdminMumberComponent,
    AdminEmpComponent,
    AdminEmpListComponent,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatGridListModule,
    MatCardModule,
    MatDialogModule,
    MatButtonToggleModule,
    MatButtonModule,
    MatTableModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
