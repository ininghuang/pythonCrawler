import { Component, OnInit } from '@angular/core';
import { EmpQAll } from 'src/app/interface/empQuery';

@Component({
  selector: 'app-admin-emp',
  templateUrl: './admin-emp.component.html',
  styleUrls: ['./admin-emp.component.css']
})
export class AdminEmpComponent {

queryMember() {
throw new Error('Method not implemented.');
}
displayedColumns=['no', 'empId', 'empName', 'password', 'anthority'] ;
dataSource:Array<EmpQAll>=[];

   constructor() { }

  ngOnInit(): void {
  }

}
