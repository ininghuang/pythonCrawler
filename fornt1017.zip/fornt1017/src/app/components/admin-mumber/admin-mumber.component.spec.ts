import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMumberComponent } from './admin-mumber.component';

describe('AdminMumberComponent', () => {
  let component: AdminMumberComponent;
  let fixture: ComponentFixture<AdminMumberComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminMumberComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminMumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
