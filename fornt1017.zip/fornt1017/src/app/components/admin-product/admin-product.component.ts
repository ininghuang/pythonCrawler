import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-product',
  templateUrl: './admin-product.component.html',
  styleUrls: ['./admin-product.component.css']
})
export class AdminProductComponent {

  constructor(private router: Router) { }

  adminPage() {
    this.router.navigate(['admin']);
  }

  mainPage() {
    this.router.navigate(['']);
  }

}
