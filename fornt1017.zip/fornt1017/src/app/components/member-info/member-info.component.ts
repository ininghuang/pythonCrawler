import { Component } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';

@Component({
  selector: 'app-member-info',
  templateUrl: './member-info.component.html',
  styleUrls: ['./member-info.component.css']
})
export class MemberInfoComponent {

  constructor(private router: Router) { }

  // 左側選單
  toggleSideNav(sideNav: MatSidenav) {
    sideNav.toggle().then((result: any) => {
      // console.log(result);
    });
  }

  memberPage() {
    this.router.navigate(['member']);
  }

  mainPage() {
    this.router.navigate(['']);
  }

}
