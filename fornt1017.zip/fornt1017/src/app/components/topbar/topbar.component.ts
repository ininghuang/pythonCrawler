import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.css']
})
export class TopbarComponent implements OnInit {
  constructor(private router: Router) { }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  navigateToPage(page: string) {
    if (page === '') {
      this.router.navigate(['']);
    } else if (page === 'admin') {
      this.router.navigate(['admin']);
    } else if (page === 'adminMember') {
      this.router.navigate(['adminMember']);
    } else if (page === 'adminOrder') {
      this.router.navigate(['adminOrder']);
    } else if (page === 'adminProduct') {
      this.router.navigate(['adminProduct']);
    }
  }

  /** 切換文字顏色 */
  hoveredButtons: { [key: string]: boolean } = {};

  isHovered(buttonName: string): boolean {
    return this.hoveredButtons[buttonName] || false;
  }

  setHovered(buttonName: string, isHovered: boolean): void {
    this.hoveredButtons[buttonName] = isHovered;
  }

  // /** 切換按鈕顏色 */
  // isHoveredBtn: boolean = false;

  // onMouseEnter() {
  //   this.isHoveredBtn = true;
  // }

  // onMouseLeave() {
  //   this.isHoveredBtn = false;
  // }

  /** 切換語言 */
  isHoveredLang = false;
  toggleLanguage(hovered: boolean) {
    this.isHoveredLang = hovered;
  }

  /** 延伸選單 */
  isDropdownOpen = false;
  toggleDropdown(open: boolean) {
    this.isDropdownOpen = open;
  }

  private closeTimeout: any;
  closeDropdown() {
    this.closeTimeout = setTimeout(() => {
      this.isDropdownOpen = false;
    }, 200);
  }

  cancelCloseTimeout() {
    if (this.closeTimeout) {
      clearTimeout(this.closeTimeout);
      this.closeTimeout = null;
    }
  }
}
