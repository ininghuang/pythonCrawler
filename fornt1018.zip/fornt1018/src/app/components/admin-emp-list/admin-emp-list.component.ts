import { Component, OnInit } from '@angular/core';
import { EmpQAll } from 'src/app/interface/empQuery';

@Component({
  selector: 'app-admin-emp-list',
  templateUrl: './admin-emp-list.component.html',
  styleUrls: ['./admin-emp-list.component.css']
})
export class AdminEmpListComponent implements OnInit {
  displayedColumns=['no', 'empId', 'empName', 'password', 'anthority'] ;
  dataSource:Array<EmpQAll>=[];
  constructor() { }

  ngOnInit(): void {
  }

}
