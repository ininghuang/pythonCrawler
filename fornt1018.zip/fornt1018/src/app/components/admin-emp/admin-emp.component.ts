import { Component, OnInit } from '@angular/core';
import { EmpQAll } from 'src/app/interface/empQuery';

interface Static{
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-admin-emp',
  templateUrl: './admin-emp.component.html',
  styleUrls: ['./admin-emp.component.css']
})
export class AdminEmpComponent {
queryMember() {
throw new Error('Method not implemented.');
}
displayedColumns=['no', 'empId', 'empName', 'password', 'anthority'] ;
dataSource:Array<EmpQAll>=[];

   constructor() { }

   allstatic: Static[] = [
    {value: 'inhouse', viewValue: '在職'},
    {value: 'resign', viewValue: '離職'},

  ];

}
