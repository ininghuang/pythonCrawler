import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-mumber',
  templateUrl: './admin-mumber.component.html',
  styleUrls: ['./admin-mumber.component.css']
})
export class AdminMumberComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
