import { Component, OnInit } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router: Router) {}

  ngOnInit() {}

  toggleSideNav(sideNav: MatSidenav) {
    sideNav.toggle().then((result: any) => {
      // console.log(result);
    });
  }

  mainPage() {
    this.router.navigate(['']);
  }

  adminMemberPage() {
    this.router.navigate(['adminMember']);
  }

  adminOrderPage() {
    this.router.navigate(['adminOrder']);
  }

  adminProductPage() {
    this.router.navigate(['adminProduct']);
  }

}
