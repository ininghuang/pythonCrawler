export interface EmpQAll{
  EMPID:String;
  EMPNAME:String;
  PASSWORD:String;
  AUTHORITY:String;
}
