import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEmpCreateComponent } from './admin-emp-create.component';

describe('AdminEmpCreateComponent', () => {
  let component: AdminEmpCreateComponent;
  let fixture: ComponentFixture<AdminEmpCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminEmpCreateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminEmpCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
