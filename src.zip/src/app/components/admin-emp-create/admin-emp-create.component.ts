import { AdminComponent } from './../admin/admin.component';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmpQAll } from 'src/app/interfaces/empQuery';
import { EmpService } from 'src/app/services/emp.service';
import Swal from 'sweetalert2';
import { MatSelectChange } from '@angular/material/select';
import { Location } from '@angular/common';
import {ErrorStateMatcher} from '@angular/material/core';


interface Authority {
  value: string;
  viewValue: string;
}
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-admin-emp-create',
  templateUrl: './admin-emp-create.component.html',
  styleUrls: ['./admin-emp-create.component.css']
})
export class AdminEmpCreateComponent implements OnInit {


  dataSource: EmpQAll[] = [];
  pageNumber = 0;
  pageSize = 5;
  length = 0;
  dataRowIndex!: number;
  isEmpIdDisabled: boolean = true;
  selectedAuthority: String | null | undefined;
  hide = true;
  title = 'refreshPage';


  constructor(
    private empService: EmpService,
    private fb: FormBuilder,
    private router: Router,
    public _location: Location
  ) { }

  form = this.fb.group({
    empId:new FormControl<any>(['',[Validators.pattern('^[0-9]*$')]]) ,
    status:new FormControl<string | null>('', Validators.required),
    authority:new FormControl<string | null>('', Validators.required),
    empName: new FormControl<string | null>('', Validators.required),
    mobile:new FormControl<string | null>('',[Validators.required,Validators.pattern('^[0-9]*$')]) ,
    email:new FormControl<string | null>('',[Validators.required,Validators.email]),
    password:new FormControl<string | null>('',[Validators.required,Validators.pattern('/^coffee/')])
  });
  matcher = new MyErrorStateMatcher();

  authoritys: Authority[] = [
    { value: 'admin', viewValue: '管理職' },
    { value: 'emp', viewValue: '一般專員' },
  ];

  ngOnInit(): void {
    this.empService.empName = this.form.value.empName;
    this.empService.status = this.form.value.status;
    this.empService.queryMaxId(
      this.form.value.empName as string,
      this.form.value.status as String,
      this.pageNumber,
      this.pageSize).subscribe(
        (response: any) => {
          console.log(response.TRANRS.items);
          const dataresponse = response.TRANRS.items
          const maxId = (Math.max(...dataresponse.map((p: { EMP_ID: String; }) => p.EMP_ID)) + 1)
          const numberMaxId = String(maxId)
          this.form.controls.empId.setValue(numberMaxId);
          this.form.controls.status.setValue("在職");
          this.form.controls.password.setValue("coffee" + numberMaxId);
        }
      );

  }

  /**  下拉選單被選擇到的值*/
  selected(event: MatSelectChange) {
    var selectedAuthority = event.value
  }

  addEmp() {
    if (this.form.controls.empId.invalid) {
      Swal.fire({ icon: 'warning', title: '新增失敗', text: '請確認員工編號 ', confirmButtonColor: 'black' });
      return;
    }
    if (this.form.controls.status.invalid) {
      Swal.fire({ icon: 'warning', title: '新增失敗', text: '請確認在職狀況 ', confirmButtonColor: 'black' });
      return;
    }
    if (this.form.controls.authority.invalid) {
      Swal.fire({ icon: 'warning', title: '新增失敗', text: '請選擇員工身分 ', confirmButtonColor: 'black' });
      return;
    }
    if (this.form.controls.empName.invalid) {
      Swal.fire({ icon: 'warning', title: '新增失敗', text: '員工姓名必填', confirmButtonColor: 'black' });
      return;
    }
    if (this.form.controls.mobile.invalid) {
      Swal.fire({ icon: 'warning', title: '新增失敗', text: '員工手機必填 ', confirmButtonColor: 'black' });
      return;
    }
    if (this.form.controls.email.invalid) {
      Swal.fire({ icon: 'warning', title: '新增失敗', text: ' 務必填寫信箱，並確認信箱格式  ', confirmButtonColor: 'black' });
      return;
    }

    this.empService.empName = this.form.value.empName;
    this.empService.password = this.form.value.password;
    this.empService.authority = this.selectedAuthority;
    this.empService.email = this.form.value.email;
    this.empService.status = this.form.value.status;
    this.empService.mobile = this.form.value.mobile;

    this.empService.createEmp(
      this.form.value.empName as String,
      this.form.value.password as String,
      this.form.value.authority as String,
      this.form.value.email as String,
      this.form.value.status as String,
      this.form.value.mobile as String,
    ).subscribe(
      (response: any) => {
        console.log(response);
        if (response.RESPONSE === "交易成功") {
          Swal.fire({ icon: 'success', title: '新增成功', confirmButtonColor: 'black' });
          window.location.reload();
        } else {
          Swal.fire({ icon: 'error', title: '新增失敗', confirmButtonColor: 'black' });
        }
      });


  }


  returnBack() {
    this.router.navigate(['emp']);
    this.empService.empName = this.form.value.empName;
    this.empService.status = this.form.value.status;
    this.empService.queryAllEmp(
      this.form.value.empName as string,
      this.form.value.status as String,
      this.pageNumber,
      this.pageSize).subscribe(
        (response: any) => {
          // console.log(response);
          if (response && response.TRANRS.items) {
            this.dataSource = response.TRANRS.items;
            this.dataRowIndex = response.TRANRS.totalCount;
          } else {
            console.log('Data not found in the response');
          }
        });

  }


}
