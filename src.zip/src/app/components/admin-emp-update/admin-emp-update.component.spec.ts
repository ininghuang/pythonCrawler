import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEmpUpdateComponent } from './admin-emp-update.component';

describe('AdminEmpUpdateComponent', () => {
  let component: AdminEmpUpdateComponent;
  let fixture: ComponentFixture<AdminEmpUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminEmpUpdateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminEmpUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
