import { AdminComponent } from './../admin/admin.component';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmpQAll } from 'src/app/interfaces/empQuery';
import { EmpService } from 'src/app/services/emp.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-admin-emp-update',
  templateUrl: './admin-emp-update.component.html',
  styleUrls: ['./admin-emp-update.component.css']
})
export class AdminEmpUpdateComponent implements OnInit {

  constructor(
    private empService: EmpService,
    private fb: FormBuilder,
    private router: Router
  ) { }

  pageNumber = 0;
  pageSize = 5;
  length = 0;
  dataRowIndex!: number;
  dataSource: EmpQAll[] = [];
  updatePageDate:String | null | undefined;

  form = this.fb.group({
    empId:new FormControl<any>('') ,
    status:new FormControl<string | null>('', Validators.required),
    authority:new FormControl<string | null>('', Validators.required),
    empName: new FormControl<string | null>('', Validators.required),
    mobile:new FormControl<string | null>('',[Validators.required,Validators.pattern('^[0-9]*$')]) ,
    email:new FormControl<string | null>('',[Validators.required,Validators.email]),
    password:new FormControl<string | null>('',[Validators.required,Validators.pattern('/^coffee/')])
  });

  ngOnInit(): void {
    const getUpdateData=this.empService.selectedData;
    this.form.controls.empId.setValue(getUpdateData.EMP_ID);
    this.form.controls.empName.setValue(getUpdateData.EMP_NAME);
    this.form.controls.status.setValue(getUpdateData.STATUS);
    this.form.controls.authority.setValue(getUpdateData.AUTHORITY);
    this.form.controls.mobile.setValue(getUpdateData.MOBILE);
    this.form.controls.email.setValue(getUpdateData.EMAIL);
    this.form.controls.password.setValue(getUpdateData.PASSWORD);



  }



  returnBack() {
    this.router.navigate(['emp']);

    this.empService.empName = this.form.value.empName;
    this.empService.status = this.form.value.status;
    this.empService.queryAllEmp(
      this.form.value.empName as string,
      this.form.value.status as String,
      this.pageNumber,
      this.pageSize).subscribe(
        (response: any) => {
          // console.log(response);
          if (response && response.TRANRS.items) {
            this.dataSource = response.TRANRS.items;
            this.dataRowIndex = response.TRANRS.totalCount;
          } else {
            console.log('Data not found in the response');
          }
        });


  }
  /** 更新Btn*/
  addEmp() {
    if (this.form.controls.empName.invalid) {
      Swal.fire({ icon: 'warning', title: '新增失敗', text: '員工姓名必填', confirmButtonColor: 'black' });
      return;
    }
    this.empService.empId = this.form.value.empId;
    this.empService.empName = this.form.value.empName;
    this.empService.password = this.form.value.password;
    this.empService.authority = this.form.value.authority;
    this.empService.email = this.form.value.email;
    this.empService.status = this.form.value.status;
    this.empService.mobile = this.form.value.mobile;

    this.empService.updateEmp(
      this.form.value.empId as String,
      this.form.value.empName as String,
      this.form.value.password as String,
      this.form.value.authority as String,
      this.form.value.email as String,
      this.form.value.status as String,
      this.form.value.mobile as String,
    ).subscribe(
      (response: any) => {
        // console.log(response);
        if (response.RESPONSE === "交易成功") {
          Swal.fire({ icon: 'success', title: '新增成功', confirmButtonColor: 'black' });
        } else {
          Swal.fire({ icon: 'error', title: '查無此員工編號', confirmButtonColor: 'black' });
        }
      });

  }





}
