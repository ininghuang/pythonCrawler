import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator, PageEvent} from '@angular/material/paginator';
import { Router } from '@angular/router';
import { EmpQAll } from 'src/app/interfaces/empQuery';
import { EmpService } from 'src/app/services/emp.service';
import Swal from 'sweetalert2';



@Component({
  selector: 'app-admin-emp',
  templateUrl: './admin-emp.component.html',
  styleUrls: ['./admin-emp.component.css']
})
export class AdminEmpComponent {
  displayedColumns = ['EMP_ID', 'STATUS', 'AUTHORITY', 'EMP_NAME', 'MOBILE', 'EMAIL', 'UPDATE'];
  dataSource: EmpQAll[] = [];
  pageNumber = 0;
  pageSize = 5;
  length = 0;
  disabled=true;
  selectedRowIndex: number = -1;
  selectedRowData = <EmpQAll>{};
  dataRowIndex!: number;
  form = this.fb.group({
    empName: new FormControl<string>('', [Validators.required, Validators.pattern(/^\S+$/)]),
    statusSelect:  [''],
  })

  constructor(
    private router: Router,
    private empService: EmpService,
    private fb: FormBuilder,

  ) { }

  allstatus = [
    { value: 'inhouse', viewValue: '在職' },
    { value: 'resign', viewValue: '離職' },
  ]

  ngOnInit(): void {
    this.empService.empName = this.form.value.empName;
    this.empService.status = this.form.value.statusSelect;
    this.empService.queryAllEmp(
      this.form.value.empName as string,
      this.form.value.statusSelect as String,
      this.pageNumber,
      this.pageSize).subscribe(
        (response: any) => {
            if (response && response.TRANRS.items) {
            this.dataSource = response.TRANRS.items;
            this.dataRowIndex = response.TRANRS.totalCount;
          }
          else {
            console.log('Data not found in the response');
          }
        });

  }

  queryBtn() {
    this.empService.empName = this.form.value.empName;
    this.empService.status = this.form.value.statusSelect;
    this.empService.queryAllEmp(
      this.form.value.empName as string,
      this.form.value.statusSelect as String,
      this.pageNumber,
      this.pageSize).subscribe(
        (response: any) => {
          if (response.RESPONSE === "查無資料") {
            Swal.fire({ icon: 'error', title: '查無此資料', confirmButtonColor: 'black' });
            return;
          }
          if (response && response.TRANRS.items) {
            this.dataSource = response.TRANRS.items;
            this.dataRowIndex = response.TRANRS.totalCount;
          }
        });

  }

  nextPage(page: PageEvent) {
    this.pageNumber = page.pageIndex;
    this.pageSize = page.pageSize;
    this.empService.queryAllEmp(
      this.form.value.empName as string,
      this.form.value.statusSelect as String,
      this.pageNumber,
      this.pageSize).subscribe(
        (response: any) => {
          console.log(response);
          this.dataSource = response.TRANRS.items;

        });
  }

  createBtu() {
    this.router.navigate(['empCreate']);
  }

  updateBtn() {
    this.router.navigate(['empUpdate']);
  }


  indexUpdate(index: number) {
    this.selectedRowIndex = index;
    this.selectedRowData = this.dataSource[index];
    console.log(this.selectedRowData);
    console.log(typeof this.selectedRowData);
    this.empService.setSelectedData(this.selectedRowData);
    this.router.navigate(['empUpdate']);
  }

}
