import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { DialogService } from 'src/app/services/dialog.service';
import { TestDialogComponent } from 'src/app/shared/test-dialog/test-dialog.component';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor(private router: Router, public dialog: MatDialog, private dialogService: DialogService) {}

  ngOnInit() {

    // if (this.dialogService.isFirstEntry) {
    //   const dialogRef = this.dialog.open(TestDialogComponent, {
    //     width: '260px',
    //     data: {
    //       title: '測驗題目',
    //       msg: `還沒想好`
    //     },
    //   });

    //   dialogRef.afterClosed().subscribe((result: string) => {
    //     if (result === 'confirm') {
    //       // console.log("送出答案");
    //     }
    //   });
    // }
    // this.dialogService.isFirstEntry = false;
  }

  toggleSideNav(sideNav: MatSidenav) {
    sideNav.toggle().then((result: any) => {
      // console.log(result);
    });
  }

  testPage() {
    this.router.navigate(['test']);
  }

  productPage() {
    this.router.navigate(['product']);
  }

  memberPage() {
    this.router.navigate(['member']);
  }

  cartPage() {
    this.router.navigate(['cart']);
  }

  product1() {
    this.router.navigate(['product1']);
  }

  product2() {
    this.router.navigate(['product2']);
  }

  product3() {
    this.router.navigate(['product3']);
  }

}
