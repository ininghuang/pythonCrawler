import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';

@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.css']
})
export class MemberComponent implements OnInit {

  constructor(private router: Router, private fb: FormBuilder,) {}

  form = this.fb.group({
    account: ['', Validators.required],
    password: ['', Validators.required],
    selectedToggle: ['login'],
  });

  ngOnInit() {}

  mainPage() {
    this.router.navigate(['']);
  }

  loginPage() {
    // 預設管理員帳密皆為 admin
    if (this.form.value.account === 'admin' && this.form.value.password === 'admin') {
      this.router.navigate(['admin']);
      return;
    }

    // 打查詢會員API確認是否有該筆帳密，若有轉導到會員基本資料，若無跳提醒視窗
    // 還沒設條件
    this.router.navigate(['memberInfo']);
  }

}
