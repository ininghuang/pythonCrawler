import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product3',
  templateUrl: './product3.component.html',
  styleUrls: ['./product3.component.css']
})
export class Product3Component {

  constructor(private router: Router) { }

  mainPage() {
    this.router.navigate(['']);
  }

}
