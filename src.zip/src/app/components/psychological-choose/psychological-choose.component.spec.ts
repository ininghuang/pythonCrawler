import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PsychologicalChooseComponent } from './psychological-choose.component';

describe('PsychologicalChooseComponent', () => {
  let component: PsychologicalChooseComponent;
  let fixture: ComponentFixture<PsychologicalChooseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PsychologicalChooseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PsychologicalChooseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
