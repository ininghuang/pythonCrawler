import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-psychological-choose',
  templateUrl: './psychological-choose.component.html',
  styleUrls: ['./psychological-choose.component.css']
})
export class PsychologicalChooseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
