import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PsychologicalanswerComponent } from './psychologicalanswer.component';

describe('PsychologicalanswerComponent', () => {
  let component: PsychologicalanswerComponent;
  let fixture: ComponentFixture<PsychologicalanswerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PsychologicalanswerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PsychologicalanswerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
