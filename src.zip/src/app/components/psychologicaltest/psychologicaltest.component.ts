import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-psychologicaltest',
  templateUrl: './psychologicaltest.component.html',
  styleUrls: ['./psychologicaltest.component.css']
})
export class PsychologicaltestComponent implements OnInit {

  constructor(private router: Router) { }


  ngOnInit(): void {

  }

  routerMain() {
    this.router.navigate(['product1']);
  }

  toProductMain() {
    this.router.navigate(['product1']);
  }


}
