import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopbarAfterComponent } from './topbar-after.component';

describe('TopbarAfterComponent', () => {
  let component: TopbarAfterComponent;
  let fixture: ComponentFixture<TopbarAfterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TopbarAfterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TopbarAfterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
