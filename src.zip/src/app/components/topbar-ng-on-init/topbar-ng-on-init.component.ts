import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topbar-ng-on-init',
  templateUrl: './topbar-ng-on-init.component.html',
  styleUrls: ['./topbar-ng-on-init.component.css']
})
export class TopbarNgOnInitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
