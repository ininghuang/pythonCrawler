export interface EmpQAll{
  EMP_ID:String;
  EMP_NAME:String;
  PASSWORD:String;
  AUTHORITY:String;
  STATUS :String;
  MOBILE:String;
  EMAIL:String;

}

export interface Item {
  productNumber: Number;
  productName: String;
  empName : String;
  status: String;
}

