import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DialogService {

  private isFirstEntered = true;

  get isFirstEntry(): boolean {
    return this.isFirstEntered;
  }

  set isFirstEntry(value: boolean) {
    this.isFirstEntered = value;
  }
}
