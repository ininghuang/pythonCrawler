import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpService {
  empId: any;
  empName: String | null | undefined;
  status: any;
  password: String | null | undefined;
  authority: String | null | undefined;
  email: String | null | undefined;
  mobile: String | null | undefined;


  constructor(private http: HttpClient) { }


  selectedData:any;
  setSelectedData(data: any) {
    this.selectedData = data;
  }

  /** 員工姓名 模糊查詢 */

  queryAllEmp(empName: String, status: String, pageNumber: number, pageSize: number): Observable<any> {
    const request = {
      EMP_NAME: empName,
      STATUS: status,
      page: {
        pageNumber: pageNumber,
        pageSize: pageSize
      }
    }
    let url = `http://localhost:8080/emp/queryByName`;
    return this.http.post<any[]>(url, request);
  }

  /** 最大員工ID */
  queryMaxId(empName: String, status: String, pageNumber: number, pageSize: number): Observable<any> {
    const request = {
      EMP_NAME: empName,
      STATUS: status,
      page: {
        pageNumber: 0,
        pageSize: 1000000000
      }
    }
    let url = `http://localhost:8080/emp/queryByName`;
    return this.http.post<any[]>(url, request);
  }

  /** 員工新增*/
  createEmp(empName: String, password: String, authority: String,
    email: String, status: String, mobile: String): Observable<any> {
    const request = {

      EMP_NAME: empName,
      PASSWORD: password,
      AUTHORITY: authority,
      EMAIL: email,
      STATUS: status,
      MOBILE: mobile,
    }
    let url = `http://localhost:8080/emp/create`;
    return this.http.post<any[]>(url, request);
  }
  /** 員工修改*/
  updateEmp(empId: String, empName: String, password: String, authority: String,
    email: String, status: String, mobile: String): Observable<any> {
    const request = {
      EMP_ID: empId,
      EMP_NAME: empName,
      PASSWORD: password,
      AUTHORITY: authority,
      EMAIL: email,
      STATUS: status,
      MOBILE: mobile,
    }
    let url = `http://localhost:8080/emp/update`;
    return this.http.post<any[]>(url, request);
  }
}
